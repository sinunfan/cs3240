this is the readme file for this shell

this program is a own shell
    the program handle
    single command eg: ls, pwd, etc
    out put to a file eg: ./hello > 77.txt
    append to the file eg: ./hello >> 77.txt
    take input file eg: ./hello < 77.txt
    out put stderr file eg: ./hello >& 77.txt
    append to the stderr file eg: ./hello >>& 77.txt
    and the pipe eg: ./shell | ./hello

    